import React from "react";
import LoginForm from "./LoginForm"; // Adjust the path if needed
import SignUpForm from "./SignUpForm"; // Adjust the path if needed

function App() {
  return (
    <div>
      <h1>Accredian login form</h1>
      <div>
        <LoginForm />
      </div>
      <div>
        <SignUpForm />
      </div>
    </div>
  );
}

export default App;
